package Model;

import Model.Monom;

import java.util.*;

public class Polinom {
    private ArrayList<Monom> Pol = new ArrayList<>();

    public Polinom(ArrayList<Monom> Pol) {
        this.Pol = Pol;
    }

    public ArrayList<Monom> getPol() {
        return Pol;
    }

    public void setPol(ArrayList<Monom> pol) {
        Pol = pol;
    }

    public void prelucrareString(String s, ArrayList<Monom> Pol) {
        Pol.removeAll(Pol); //Eliberam lista, in cazul in care am prelucrat un alt polinom inainte
        int maxp = 0; //puterea maxima
        for (int i = 0; i < s.length(); i++) {
            String nr = "";
            Monom a = new Monom(0, 0);
            if ((s.charAt(i) > 'a') && (s.charAt(i) < 'z')) { //Stabilim semnul in cazul in care nu se adauga coeficient == 1
                if (i == 0 || s.charAt(i - 1) == '+') {
                    nr = "+1";
                } else if (s.charAt(i - 1) == '-') {
                    nr = "-1";
                } else {
                    int j = i - 1; // Luam cifrele coeficientului pe rand
                    while (((j >= 0) && ((s.charAt(j) >= '0') && (s.charAt(j) <= '9') && (s.charAt(j + 1) != '-')))|| (s.charAt(j) == '-')) {
                        nr = s.charAt(j) + nr;
                        j--;
                        if (j == -1) {
                            break;
                        }
                    }
                }
                a.setCoefficient(Integer.parseInt(nr)); //Stabilim coeficientul
                int j = i + 2; //Trecem la exponent
                nr = "";
                while (j <= s.length() && s.charAt(j) != '-' && s.charAt(j) != '+') {
                    nr = nr + s.charAt(j);
                    j++;
                    if (j == s.length()) {  // daca am ajuns la ultimul monom, ne oprim
                        break;
                    }
                }
                a.setPower(Integer.parseInt(nr)); //setam puterea
                if (maxp < a.getPower()) {
                    maxp = a.getPower(); // ne folosim de maxpow la sortare
                }
                Pol.add(a);
            }
        }
    }

    public void sortare(ArrayList<Monom> Lista) {
        Collections.sort(Lista, new Comparator<Monom>() {

            public int compare(Monom m1, Monom m2) {
                return (m2.getPower() - m1.getPower()); //sortam dupa putere
            }
        });
        int maxp = Lista.get(0).getPower();
        for (int i = 0; i < maxp; i++) {
            boolean conditie = false;
            for (int j = 0; j < Pol.size(); j++) {
                if (Pol.get(j).getPower() == i) {
                    conditie = true;
                }
            }
            if (conditie == false)
                Pol.add(new Monom(0, i));
        }

    }

}