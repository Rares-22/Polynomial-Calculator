import Controller.Operatii;
import Model.Monom;
import Model.Polinom;
import org.junit.Assert;
import org.junit.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.ArrayList;


public class Testing {
    @Test
    public void testAddiction() {
        String text1 = "";
        Monom m1 = new Monom(1, 2);
        Monom m2 = new Monom(4, 3);
        Monom m3 = new Monom(5, 2);
        Monom m4 = new Monom(6, 3);
        ArrayList<Monom> Lista1 = new ArrayList<>();
        ArrayList<Monom> Lista2 = new ArrayList<>();
        Lista1.add(m1);
        Lista1.add(m2);
        Lista2.add(m3);
        Lista2.add(m4);
        Polinom Polinom1 = new Polinom(Lista1);
        Polinom Polinom2 = new Polinom(Lista2);
        Polinom Rezultat = new Polinom(null);
        Operatii op = new Operatii(Polinom1, Polinom2, Rezultat);

        Polinom1.sortare(Polinom1.getPol());
        Polinom1.setPol(Polinom1.getPol());
        Polinom2.sortare(Polinom2.getPol());
        Polinom2.setPol(Polinom2.getPol());

        op.addiction(Polinom1, Polinom2, Rezultat);

        Rezultat.sortare(Rezultat.getPol());
        Rezultat.setPol(Rezultat.getPol());

        for (Monom item : Rezultat.getPol()) {
            if (item.getCoefficient() != 0) {
                if (item.getCoefficient() < 0) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else if (item.getPower() == Rezultat.getPol().get(0).getPower()) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else {
                    text1 = text1 + '+' + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                }

            }
        }
        Assert.assertEquals("10x^3+6x^2", text1);

    }


    @Test
    public void testMultiply() {
        String text1 = "";
        Monom m1 = new Monom(1, 2);
        Monom m2 = new Monom(4, 3);
        Monom m3 = new Monom(5, 2);
        Monom m4 = new Monom(6, 3);
        ArrayList<Monom> Lista1 = new ArrayList<>();
        ArrayList<Monom> Lista2 = new ArrayList<>();
        Lista1.add(m1);
        Lista1.add(m2);
        Lista2.add(m3);
        Lista2.add(m4);
        Polinom Polinom1 = new Polinom(Lista1);
        Polinom Polinom2 = new Polinom(Lista2);
        Polinom Rezultat = new Polinom(null);
        Operatii op = new Operatii(Polinom1, Polinom2, Rezultat);

        Polinom1.sortare(Polinom1.getPol());
        Polinom1.setPol(Polinom1.getPol());
        Polinom2.sortare(Polinom2.getPol());
        Polinom2.setPol(Polinom2.getPol());

        op.multiplication(Polinom1, Polinom2, Rezultat);

        Rezultat.sortare(Rezultat.getPol());
        Rezultat.setPol(Rezultat.getPol());

        for (Monom item : Rezultat.getPol()) {
            if (item.getCoefficient() != 0) {
                if (item.getCoefficient() < 0) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else if (item.getPower() == Rezultat.getPol().get(0).getPower()) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else {
                    text1 = text1 + '+' + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                }

            }
        }
        Assert.assertEquals("24x^6+26x^5+5x^4", text1);

    }


    @Test
    public void testSubtraction() {
        String text1 = "";
        Monom m1 = new Monom(1, 2);
        Monom m2 = new Monom(4, 3);
        Monom m3 = new Monom(5, 2);
        Monom m4 = new Monom(6, 3);
        ArrayList<Monom> Lista1 = new ArrayList<>();
        ArrayList<Monom> Lista2 = new ArrayList<>();
        Lista1.add(m1);
        Lista1.add(m2);
        Lista2.add(m3);
        Lista2.add(m4);
        Polinom Polinom1 = new Polinom(Lista1);
        Polinom Polinom2 = new Polinom(Lista2);
        Polinom Rezultat = new Polinom(null);
        Operatii op = new Operatii(Polinom1, Polinom2, Rezultat);

        Polinom1.sortare(Polinom1.getPol());
        Polinom1.setPol(Polinom1.getPol());
        Polinom2.sortare(Polinom2.getPol());
        Polinom2.setPol(Polinom2.getPol());

        op.subtraction(Polinom1, Polinom2, Rezultat);

        Rezultat.sortare(Rezultat.getPol());
        Rezultat.setPol(Rezultat.getPol());

        for (Monom item : Rezultat.getPol()) {
            if (item.getCoefficient() != 0) {
                if (item.getCoefficient() < 0) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else if (item.getPower() == Rezultat.getPol().get(0).getPower()) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else {
                    text1 = text1 + '+' + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                }

            }
        }
        Assert.assertEquals("-2x^3-4x^2", text1);

    }


    @Test
    public void testDerivative() {
        String text1 = "";
        Monom m1 = new Monom(1, 2);
        Monom m2 = new Monom(4, 3);
        ArrayList<Monom> Lista1 = new ArrayList<>();
        Lista1.add(m1);
        Lista1.add(m2);

        Polinom Polinom1 = new Polinom(Lista1);
        Polinom Polinom2 = new Polinom(null);
        Polinom Rezultat = new Polinom(null);
        Operatii op = new Operatii(Polinom1, Polinom2, Rezultat);

        Polinom1.sortare(Polinom1.getPol());
        Polinom1.setPol(Polinom1.getPol());

        op.derivative(Polinom1, Rezultat);

        Rezultat.sortare(Rezultat.getPol());
        Rezultat.setPol(Rezultat.getPol());

        for (Monom item : Rezultat.getPol()) {
            if (item.getCoefficient() != 0) {
                if (item.getCoefficient() < 0) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else if (item.getPower() == Rezultat.getPol().get(0).getPower()) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                } else {
                    text1 = text1 + '+' + String.valueOf(item.getCoefficient()) + "x^" + String.valueOf(item.getPower());
                }

            }
        }
        Assert.assertEquals("12x^2+2x^1", text1);

    }

    @Test
    public void testIntegration() {
        String text1 = "";
        Monom m1 = new Monom(1, 2);
        Monom m2 = new Monom(4, 3);
        ArrayList<Monom> Lista1 = new ArrayList<>();
        Lista1.add(m1);
        Lista1.add(m2);

        Polinom Polinom1 = new Polinom(Lista1);
        Polinom Polinom2 = new Polinom(null);
        Polinom Rezultat = new Polinom(null);
        Operatii op = new Operatii(Polinom1, Polinom2, Rezultat);

        Polinom1.sortare(Polinom1.getPol());
        Polinom1.setPol(Polinom1.getPol());

        op.integration(Polinom1, Rezultat);

        Rezultat.sortare(Rezultat.getPol());
        Rezultat.setPol(Rezultat.getPol());

        for (Monom item : Rezultat.getPol()) {
            if (item.getCoefficient() != 0) {
                if (item.getCoefficient() < 0) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + '/' + String.valueOf(item.getPower()) + "x^"
                            + String.valueOf(item.getPower());
                } else if (item.getPower() == Rezultat.getPol().get(0).getPower()) {
                    text1 = text1 + String.valueOf(item.getCoefficient()) + '/' + String.valueOf(item.getPower()) + "x^"
                            + String.valueOf(item.getPower());
                } else {
                    text1 = text1 + '+' + String.valueOf(item.getCoefficient()) + '/' + String.valueOf(item.getPower())
                            + "x^" + String.valueOf(item.getPower());
                }
            }
        }
        Assert.assertEquals("4/4x^4+1/3x^3", text1);

    }

}