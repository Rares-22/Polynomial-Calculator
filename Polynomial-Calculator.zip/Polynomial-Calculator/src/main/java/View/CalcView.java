package View;
import Controller.Operatii;
import Model.Monom;
import Model.Polinom;

import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class CalcView extends JFrame {
    public static void main(String[] args) {
        final JFrame f = new JFrame("Calculator Polinoame");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(600, 300);
        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        JPanel p4 = new JPanel();
        JLabel l1 = new JLabel("Introduceti polinoamele");
        final JTextField tf1 = new JTextField(20);
        final JTextField tf3 = new JTextField(20);
        JLabel l2 = new JLabel("Rezultatul e");
        JLabel l3 = new JLabel(
                "Date de intrare trebuie introduse dupa formatul urmator: a1x^n+a2x^n-1+...+a(n-1)x^1+anx^0");
        final JTextField tf2 = new JTextField(30);
        p4.add(l3);
        p1.add(l1);
        p1.add(tf1);
        p1.add(tf3);
        p3.add(l2);
        p3.add(tf2);
        JButton b1 = new JButton("+");
        JButton b2 = new JButton("-");
        JButton b3 = new JButton("*");
        JButton b4 = new JButton("/");
        JButton b5 = new JButton("'");
        JButton b6 = new JButton("S");
        p2.add(b1);
        p2.add(b2);
        p2.add(b3);
        p2.add(b4);
        p2.add(b5);
        p2.add(b6);
        JPanel p = new JPanel();
        p.add(p4);
        p.add(p1);
        p.add(p2);
        p.add(p3);
        final ArrayList<Monom> L1 = new ArrayList<Monom>();
        final ArrayList<Monom> L2 = new ArrayList<Monom>();
        ArrayList<Monom> rezl = new ArrayList<Monom>();
        final Polinom Poli1 = new Polinom(L1);
        final Polinom Poli2 = new Polinom(L2);
        final Polinom rez = new Polinom(rezl);
        final Operatii op = new Operatii(Poli1, Poli2, rez);

        b1.addActionListener(new ActionListener() {
            String text1;
            String text2;
            public void actionPerformed(ActionEvent e) {
                text1 = (String) tf1.getText();
                text2 = (String) tf3.getText();
                try {
                    Poli1.prelucrareString(text1, L1);
                    Poli2.prelucrareString(text2, L2);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(f, "Datele introduse sunt incorecte");
                    return;
                }
                Poli1.sortare(L1);
                Poli1.setPol(L1);
                Poli2.sortare(L2);
                Poli2.setPol(L2);
                op.addiction(Poli1, Poli2, rez);
                rez.sortare(rez.getPol());
                text1 = "";
                for (Monom mon : rez.getPol()) {
                    if (mon.getCoefficient() != 0) {
                        if (mon.getCoefficient() < 0) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else if (mon.getPower() == rez.getPol().get(0).getPower()) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else {
                            text1 = text1 + '+' + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        }
                    }
                }
                tf2.setText(text1);
            }
        });

        b2.addActionListener(new ActionListener() {
            String text1 = "";
            String text2 = "";

            public void actionPerformed(ActionEvent e) {
                text1 = (String) tf1.getText();
                text2 = (String) tf3.getText();
                try {
                    Poli1.prelucrareString(text1, L1);
                    Poli2.prelucrareString(text2, L2);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(f, "Datele introduse sunt incorecte");
                    return;
                }
                Poli1.sortare(L1);
                Poli1.setPol(L1);
                Poli2.sortare(L2);
                Poli2.setPol(L2);
                op.subtraction(Poli1, Poli2, rez);
                rez.sortare(rez.getPol());
                text1 = "";
                for (Monom mon : rez.getPol()) {
                    if (mon.getCoefficient() != 0) {
                        if (mon.getCoefficient() < 0) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else if (mon.getPower() == rez.getPol().get(0).getPower()) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else {
                            text1 = text1 + '+' + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        }
                    }
                }
                if (text1 == "") {
                    text1 = "0";
                }
                tf2.setText(text1);
            }
        });

        b5.addActionListener(new ActionListener() {
            String text1 = "";

            public void actionPerformed(ActionEvent e) {
                text1 = (String) tf1.getText();
                try {
                    Poli1.prelucrareString(text1, L1);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(f, "Datele introduse sunt incorecte");
                    return;
                }
                Poli1.sortare(L1);
                Poli1.setPol(L1);
                op.derivative(Poli1, rez);
                rez.sortare(rez.getPol());
                text1 = "";
                for (Monom mon : rez.getPol()) {
                    if (mon.getCoefficient() != 0) {
                        if (mon.getCoefficient() < 0) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else if (mon.getPower() == rez.getPol().get(0).getPower()) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else {
                            text1 = text1 + '+' + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        }
                    }
                }
                tf2.setText(text1);
            }
        });

        b3.addActionListener(new ActionListener() {
            String text1 = "";
            String text2;

            public void actionPerformed(ActionEvent e) {
                text1 = (String) tf1.getText();
                text2 = (String) tf3.getText();
                try {
                    Poli1.prelucrareString(text1, L1);
                    Poli2.prelucrareString(text2, L2);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(f, "Datele introduse sunt incorecte");
                    return;
                }
                Poli1.sortare(L1);
                Poli1.setPol(L1);
                Poli2.sortare(L2);
                Poli2.setPol(L2);
                op.multiplication(Poli1, Poli2, rez);
                rez.sortare(rez.getPol());
                text1 = "";
                for (Monom mon : rez.getPol()) {
                    if (mon.getCoefficient() != 0) {
                        if (mon.getCoefficient() < 0) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else if (mon.getPower() == rez.getPol().get(0).getPower()) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        } else {
                            text1 = text1 + '+' + String.valueOf(mon.getCoefficient()) + "x^" + String.valueOf(mon.getPower());
                        }
                    }
                }
                tf2.setText(text1);
            }
        });

        b6.addActionListener(new ActionListener() {
            String text1 = "";

            public void actionPerformed(ActionEvent e) {
                text1 = (String) tf1.getText();
                try {
                    Poli1.prelucrareString(text1, L1);
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(f, "Datele introduse sunt incorecte");
                    return;
                }
                Poli1.sortare(L1);
                Poli1.setPol(L1);
                op.integration(Poli1, rez);
                rez.sortare(rez.getPol());
                text1 = "";
                for (Monom mon : rez.getPol()) {
                    if (mon.getCoefficient() != 0) {
                        if (mon.getCoefficient() < 0) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + '/' + String.valueOf(mon.getPower()) + "x^"
                                    + String.valueOf(mon.getPower());
                        } else if (mon.getPower() == rez.getPol().get(0).getPower()) {
                            text1 = text1 + String.valueOf(mon.getCoefficient()) + '/' + String.valueOf(mon.getPower()) + "x^"
                                    + String.valueOf(mon.getPower());
                        } else {
                            text1 = text1 + '+' + String.valueOf(mon.getCoefficient()) + '/' + String.valueOf(mon.getPower())
                                    + "x^" + String.valueOf(mon.getPower());
                        }
                    }
                }
                tf2.setText(text1);
            }
        });
        b4.addActionListener(new ActionListener() {
            String text1 = "";

            public void actionPerformed(ActionEvent e) {
                text1 = "Operatie necunoscuta";
                tf2.setText(text1);
            }
        });
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        f.setContentPane(p);
        f.setVisible(true);
    }
}
