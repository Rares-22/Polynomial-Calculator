package Controller;

import Model.Monom;
import Model.Polinom;

import java.util.*;

public class Operatii {
    private Polinom Poli1;
    private Polinom Poli2;
    private Polinom rez;
    public Operatii (Polinom Poli1, Polinom Poli2, Polinom rez)
    {
        this.Poli1=Poli1;
        this.Poli2=Poli2;
        this.rez=rez;
    }
    public Polinom getPol2() {
        return Poli2;
    }
    public void setPol2(Polinom pol2) {
        Poli2 = pol2;
    }
    public Polinom getPol1() {
        return Poli1;
    }
    public void setPol1(Polinom pol1) {
        Poli1 = pol1;
    }
    public Polinom getRez() {
        return rez;
    }
    public void setRez(Polinom rez) {
        this.rez = rez;
    }
    public void addiction(Polinom Poli1, Polinom Poli2, Polinom rez)
    {
        ArrayList<Monom> ListAux = new ArrayList<Monom>();
        if  (Poli1.getPol().get(0).getPower()<=Poli2.getPol().get(0).getPower()) {
            for (Monom mon : Poli1.getPol())
            {   int suma=Poli1.getPol().get(Poli1.getPol().get(0).getPower()-mon.getPower()).getCoefficient()+Poli2.getPol().get(Poli2.getPol().get(0).getPower()-mon.getPower()).getCoefficient();
                ListAux.add(new Monom (suma,Poli1.getPol().get(Poli1.getPol().get(0).getPower()-mon.getPower()).getPower()));
            }
            for (int i=Poli2.getPol().get(0).getPower(); i>Poli1.getPol().get(0).getPower(); i--)
            {
                ListAux.add(new Monom (Poli2.getPol().get(Poli2.getPol().get(0).getPower()-i).getCoefficient(),Poli2.getPol().get(Poli2.getPol().get(0).getPower()-i).getPower()));
            }
        }
        else
        {
            for (Monom mon : Poli2.getPol())
            {   int suma=Poli2.getPol().get(Poli2.getPol().get(0).getPower()-mon.getPower()).getCoefficient()+Poli1.getPol().get(Poli1.getPol().get(0).getPower()-mon.getPower()).getCoefficient();
                ListAux.add(new Monom (suma,Poli2.getPol().get(Poli2.getPol().get(0).getPower()-mon.getPower()).getPower()));
            }
            for (int i=Poli1.getPol().get(0).getPower(); i>Poli2.getPol().get(0).getPower(); i--)
            {
                ListAux.add(new Monom (Poli1.getPol().get(Poli1.getPol().get(0).getPower()-i).getCoefficient(),Poli1.getPol().get(Poli1.getPol().get(0).getPower()-i).getPower()));
            }
        }

        rez.setPol(ListAux);
    }

    public void subtraction(Polinom Poli1, Polinom Poli2, Polinom rez)
    {
        for (Monom mon:Poli2.getPol())
        {
            Poli2.getPol().get(mon.getPower()).setCoefficient(-Poli2.getPol().get(mon.getPower()).getCoefficient());
            //Schimbam semnul coeficientilor de la al 2-lea polinom, iar apoi il adunam la primul
        }
        addiction(Poli1,Poli2,rez);

    }

    public void multiplication(Polinom Poli1, Polinom Poli2, Polinom rez)
    {
        ArrayList<Monom> ListAux = new ArrayList<Monom>();
        ArrayList<Monom> ListAux1 = new ArrayList<Monom>();
        for (Monom mon:Poli1.getPol())
        {
            for (Monom mon1:Poli2.getPol())
            {
                ListAux.add(new Monom (mon.getCoefficient()*mon1.getCoefficient(),mon.getPower()+mon1.getPower()));
                // Inmultim coeficientii si adunam puterile
            }
        }
        int pow=Poli1.getPol().get(0).getPower()+Poli2.getPol().get(0).getPower(); //calculam puterea maxima
        for (int i=pow;i>=0;i--)
        {int sumacoeficientilor=0;
            for (Monom mon:ListAux)
            {
                if (mon.getPower()==i)
                {
                    sumacoeficientilor=sumacoeficientilor+mon.getCoefficient(); //calculam suma coeficientilor pentru monoamele de acelasi grad
                }
            }
            ListAux1.add(new Monom (sumacoeficientilor,i));
        }
        rez.setPol(ListAux1);
    }


    public void derivative(Polinom Poli1, Polinom rez)
    {
        ArrayList<Monom> ListAux = new ArrayList<Monom>();
        for (Monom mon:Poli1.getPol())
        {
            if (  mon.getPower()!=0)
            {
                ListAux.add(new Monom (mon.getCoefficient()*mon.getPower(),mon.getPower()-1));
                //inmultim puterea la coeficient, iar din putere scadem 1
            }
        }
        rez.setPol(ListAux);

    }

    public void integration(Polinom Poli1, Polinom rez)
    {
        ArrayList<Monom> ListAux = new ArrayList<Monom>();
        for (Monom mon:Poli1.getPol())
        {

            ListAux.add(new Monom (mon.getCoefficient(),mon.getPower()+1));
            //Adunam la putere 1, iar coeficientul il modificam la afisare
        }
        rez.setPol(ListAux);

    }


}
